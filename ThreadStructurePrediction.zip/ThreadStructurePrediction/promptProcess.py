import pandas as pd
import glob

if __name__ == "__main__":
	testSentence = """You are given two posts and you need to generate 1 if they are the direct reply relation, otherwise generate 0.
	input:
	sentence 1: To make things easier, we can stretch it
	sentence 2: and convert to grayscale
	output:1
	input:
	sentence 1: and convert to grayscale
	sentence 2: To make things easier, we can stretch it
	output:0
	input:
	sentence 1: """

	#For each dataset, create
	datasetList = ["cor", "mam", "ctf"]
	for dsName in datasetList:
		filenames = glob.glob("./" + dsName +"/*.csv")
		for filename in filenames:
			newDataset = []
			df = pd.read_csv(filename)
			pPostL = df["sentence1"].tolist()
			rPostL = df["sentence2"].tolist()
			labelL = df["label"].tolist()

			for i in range(len(labelL)):
				# Template
				triplet = []
				sent1 = testSentence + str(pPostL[i])

				triplet.append(sent1)
				triplet.append("sentence 2: " + str(rPostL[i]))
				triplet.append(labelL[i])
				newDataset.append(triplet)

			df1 = pd.DataFrame(newDataset, columns=["sentence1", "sentence2", "label"])
			outfilename = filename.replace("./", "./prompt/")
			df1.to_csv(outfilename)