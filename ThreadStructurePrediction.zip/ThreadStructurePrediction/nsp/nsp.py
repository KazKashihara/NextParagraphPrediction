import pandas as pd
import json
import numpy as np



def equal_distribute(df):
  df_2=pd.DataFrame()
  length = []
  for key,data in df.groupby('label'):
    length.append(len(data))
  for key,data in df.groupby('label'):
    # print(key)
    # print(data.sample(n=min(length)))
    df_2 = df_2.append(data.sample(n=min(length)))

  #shuffle the data  
  df_2=df_2.sample(frac=1)
  return df_2


# In[16]:


df_trainsen_eq = equal_distribute(df_trainsen)



df_trainsen_eq.to_csv('../ctf/temp/trainsen_eq.csv')
df_devsen.to_csv('../ctf/temp/devsen_eq.csv')


# In[18]:


# # df_trainsen_0_eq = equal_distribute(df_trainsen_0)
# # df_devsen_0_eq = equal_distribute(df_devsen_0)
# # df_testsen_0_eq = equal_distribute(df_testsen_0)
# df_trainsen_3_eq = equal_distribute(df_trainsen_3)
# df_devsen_3_eq = equal_distribute(df_devsen_3)
# df_testsen_3_eq = equal_distribute(df_testsen_3)
# df_trainsen_4_eq = equal_distribute(df_trainsen_4)
# df_devsen_4_eq = equal_distribute(df_devsen_4)
# df_testsen_4_eq = equal_distribute(df_testsen_4)
# df_trainsen_5_eq = equal_distribute(df_trainsen_5)
# df_devsen_5_eq = equal_distribute(df_devsen_5)
# df_testsen_5_eq = equal_distribute(df_testsen_5)
# # df_trainsen_0_eq.to_csv('/content/ctf/trainsen_eq_0.csv')
# # df_devsen_0_eq.to_csv('/content/devsen_eq_0.csv')
# # df_testsen_0_eq.to_csv('/content/testsen_eq_0.csv')
# df_trainsen_3_eq.to_csv('/content/ctf/trainsen_eq_3.csv')
# df_devsen_3_eq.to_csv('/content/ctf/devsen_eq_3.csv')
# df_testsen_3_eq.to_csv('/content/ctf/testsen_eq_3.csv')
# df_trainsen_4_eq.to_csv('/content/ctf/trainsen_eq_4.csv')
# df_devsen_4_eq.to_csv('/content/ctf/devsen_eq_4.csv')
# df_testsen_4_eq.to_csv('/content/ctf/testsen_eq_4.csv')
# df_trainsen_5_eq.to_csv('/content/ctf/trainsen_eq_5.csv')
# df_devsen_5_eq.to_csv('/content/ctf/devsen_eq_5.csv')
# df_testsen_5_eq.to_csv('/content/ctf/testsen_eq_5.csv')


# In[19]:


# get_ipython().system('pip install TensorBoard==1.15 ')


# In[ ]:


# !export CUDA_VISIBLE_DEVICES=-1


# In[21]:


get_ipython().system("python training.py '../ctf/temp/trainsen_eq.csv' '../ctf/temp/devsen_eq.csv'")


# 

# 

# In[ ]:


# import os
# os.listdir("/content/lightning_logs/version_0/checkpoints")


# In[ ]:


# from sklearn.metrics import classification_report,roc_auc_score 
# from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score

# def accuracy_metric(preds, labels):
#     assert len(preds) == len(labels)
#     out = {‘accuracy’: accuracy_score(preds, labels),
#            ‘precision’: precision_score(labels, preds),
#            ‘recall’: recall_score(labels, preds),
#            ‘f1’: f1_score(labels, preds),
#            ‘classification_report’:classification_report(labels, preds),
#            ‘roc_auc_score’:roc_auc_score(labels,preds)}
#     return out
    


# In[ ]:


# get_ipython().system('ls -l /content/lightning_logs/version_0/checkpoints')
# get_ipython().system('mv /content/lightning_logs/version_0/checkpoints/\'epoch=2.ckpt\' "/content/security_equal.ckpt"')


# # In[ ]:


# # from google.colab import drive
# # drive.mount('/content/drive')


# # In[ ]:


# # !gsutil cp -r "/content/security_equal.ckpt" "/content/drive/My Drive/OOD Checkpoints"


# # In[ ]:


# get_ipython().system('python validation.py "/content/security_equal.ckpt" "/content/devsen_eq.csv"')


# # In[ ]:


# from google.colab import drive
# drive.mount('/content/drive')


# # In[ ]:


# get_ipython().system('cp "/content/security_equal.ckpt" "/content/drive/MyDrive/curriculam learning"')

