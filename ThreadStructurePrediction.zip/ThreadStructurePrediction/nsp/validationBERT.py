import torch
from torch import nn
import pytorch_lightning as pl
from torch.nn import functional as F
import pandas as pd
import numpy as np
import random
from transformers import AutoConfig, AutoModel, AutoTokenizer
from torch.utils.data import Dataset, DataLoader
import sys
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score, precision_score
from sklearn.metrics import roc_auc_score, auc, roc_curve
from sklearn.metrics import classification_report
from sklearn.metrics import precision_recall_curve
from sklearn import metrics
#"MODEL_PATH": "/home/srmishr1/AFLite_2/lightning_logs/version_5042469/checkpoints/epoch=2.ckpt",
#"EVAL_FILE": "/scratch/srmishr1/bhavdeep_DQI/snli/snli_1.0/snli_1.0_dev.csv",
#print(sys.argv[1])
parameters = {
    "BaseModel": "bert-large-uncased",
    "num_labels": 2,
    "hidden_dropout_prob": 0.15,
    "MODEL_PATH": sys.argv[1],
    "EVAL_FILE": sys.argv[2],
    "max_length": 250,
    "batch_size": 8,
    "learning_rate": 5e-6,
    "epochs": 3,
}


overall_labels_test = []
overall_logits_test = []
sent1List = []
sent2List = []

def set_seed(seed):
    """
    Set the random seed.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class NLIDataset(Dataset):
    def __init__(self, df):
        self.df = df
        self.tokenizer = AutoTokenizer.from_pretrained(parameters["BaseModel"])
        self.label_list = []
        sent1List = self.df["sentence1"]
        sent2List = self.df["sentence2"]
        for label in self.df["label"]:
            if label == 0:
                self.label_list.append(0)
            elif label == 1:
                self.label_list.append(1)
            else:
                print("Incorrect Label")

    def __getitem__(self, index):
        sentence1 = self.df.iloc[index]["sentence1"]
        sentence2 = self.df.iloc[index]["sentence2"]
        #label = self.df.iloc[index]["label"]
        label = self.df.iloc[index]["label"]
        encoded_input = self.tokenizer.encode_plus(
            sentence1,
            sentence2,
            add_special_tokens=True,
            truncation=True,
            max_length=parameters["max_length"],
            pad_to_max_length=True,
            return_overflowing_tokens=True,
        )
        if "num_truncated_tokens" in encoded_input and encoded_input["num_truncated_tokens"] > 0:
            # print("Attention! you are cropping tokens")
            pass

        input_ids = encoded_input["input_ids"]
        attention_mask = encoded_input["attention_mask"] if "attention_mask" in encoded_input else None

        token_type_ids = encoded_input["token_type_ids"] if "token_type_ids" in encoded_input else None


        data_input = {
            "input_ids": torch.tensor(input_ids),
            "attention_mask": torch.tensor(attention_mask),
            "labels": torch.tensor(self.label_list[index]),
        }
        if (token_type_ids != None):
            data_input["token_type_ids"] = torch.tensor(token_type_ids)

        return data_input

    def __len__(self):
        return self.df.shape[0]


class ValidationModel(pl.LightningModule):
    def __init__(self):
        super(ValidationModel, self).__init__()

        self.config = AutoConfig.from_pretrained(parameters["BaseModel"], num_labels=parameters["num_labels"],
                                                 hidden_dropout_prob=parameters["hidden_dropout_prob"])
        self.base_model = AutoModel.from_pretrained(parameters["BaseModel"], config=self.config)
        #self.base_model =
        self.dropout = nn.Dropout(self.config.hidden_dropout_prob)
        self.classifier = nn.Sequential(
            nn.Linear(self.config.hidden_size, self.config.num_labels),
        )
        self.overall_logits_val = []
        self.overall_labels_val =[]
        # self.overall_logits_test = []
        # self.overall_labels_test =[]
        global overall_labels_test
        global overall_logits_test
      

    def forward(self,
                input_ids=None,
                attention_mask=None,
                token_type_ids=None,
                labels=None):

        outputs = self.base_model(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        pooled_output = outputs[1]
        dropout_pooled_output = self.dropout(pooled_output)

        logits = self.classifier(dropout_pooled_output)
        softmax_logits = F.softmax(logits, dim=1)
        return pooled_output, logits, softmax_logits

    def prepare_data(self):
        dev_df = pd.read_csv(parameters["EVAL_FILE"])
        self.dev_dataset = NLIDataset(dev_df)

    def val_dataloader(self):
        return DataLoader(dataset=self.dev_dataset, batch_size=parameters["batch_size"], num_workers=8)

    def test_dataloader(self):
        return DataLoader(dataset=self.dev_dataset, batch_size=parameters["batch_size"], num_workers=8)

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=parameters["learning_rate"])

    def loss_function(self, logits, labels):

        loss_fn = torch.nn.CrossEntropyLoss()

        return loss_fn(logits, labels)

    def compute_accuracy(self, logits, labels):
        predicted_label = logits.max(dim=1)[1]
        acc = (predicted_label == labels).float().mean()

        return acc

    def validation_step(self, batch, batch_idx):
        bert_output, logits, softmax_logits = self.forward(**batch)
        loss = self.loss_function(logits, batch["labels"])

        accuracy = self.compute_accuracy(logits, batch["labels"])
        self.overall_logits_val.extend(logits.cpu().data.numpy().argmax(axis=1))
        self.overall_labels_val.extend(batch["labels"].cpu().data.numpy())

        # print(self.overall_logits_val)
        return {"val_loss": loss,
                "accuracy": accuracy,
               }
    def test_step(self, batch, batch_idx):
        bert_output, logits, softmax_logits = self.forward(**batch)
        loss = self.loss_function(logits, batch["labels"])
        # m = nn.LogSoftmax(dim=1)
        # self.overall_logits_test.extend(logits.cpu().data.numpy().argmax(axis=1))
        # self.overall_labels_test.extend(batch["labels"].cpu().data.numpy())
        overall_logits_test.extend(logits.cpu().data.numpy().argmax(axis=1))
        overall_labels_test.extend(batch["labels"].cpu().data.numpy())

        accuracy = self.compute_accuracy(logits, batch["labels"])

        # print(self.overall_logits_test)
        return {"val_loss": loss,
                "accuracy": accuracy,
               }

    def validation_epoch_end(self, outputs_of_validation_steps):
        avg_loss = torch.stack([x['val_loss'] for x in outputs_of_validation_steps]).mean()
        val_accuracy = torch.stack([x['accuracy'] for x in outputs_of_validation_steps]).mean()
        f1 = f1_score(self.overall_logits_val, self.overall_labels_val)
        precision = precision_score(self.overall_logits_val, self.overall_labels_val)
        recall = recall_score(self.overall_logits_val, self.overall_labels_val)


        if (len(({0}-set(self.overall_logits_val)).union(set(self.overall_logits_val)-{0})))!=0:
          auc = roc_auc_score(self.overall_logits_val, self.overall_labels_val)
          # fpr, tpr, thresholds = metrics.roc_curve(self.overall_logits_val, self.overall_labels_val, pos_label=2)
          # auc = metrics.auc(fpr, tpr)
        else:
          auc=0
        print(classification_report(self.overall_logits_val, self.overall_labels_val))
        print("val accuracy: ", val_accuracy)
        print("f1: ", f1)
        print("precision: ",precision)
        print("auc: ", auc)
        print("recall: ", recall)

        log = {"val_loss": avg_loss,
                "accuracy": val_accuracy,
                "f1": f1,
                "precision":precision,
                "auc":auc,
                "recall":recall
        }

        return {"val_loss": avg_loss,
                "accuracy": val_accuracy,
                "f1": f1,
                "precision":precision,
                "auc":auc,
                "recall":recall,
                "log":log
        }


    def test_end(self, outputs_of_validation_steps):
        print("Inside Test END")
        avg_loss = torch.stack([x['val_loss'] for x in outputs_of_validation_steps]).mean()
        val_accuracy = torch.stack([x['accuracy'] for x in outputs_of_validation_steps]).mean()
        f1 = f1_score(self.overall_logits_test, self.overall_labels_test)
        precision = precision_score(self.overall_logits_test, self.overall_labels_test)
        recall = recall_score(self.overall_logits_test, self.overall_labels_test)


        if (len(({0}-set(self.overall_logits_test)).union(set(self.overall_logits_test)-{0})))!=0:
          auc = roc_auc_score(self.overall_logits_test, self.overall_labels_test)
          # fpr, tpr, thresholds = metrics.roc_curve(self.overall_logits_val, self.overall_labels_val, pos_label=2)
          # auc = metrics.auc(fpr, tpr)
        else:
          auc=0
        print(classification_report(self.overall_logits_test, self.overall_labels_test))
        print("val accuracy: ", val_accuracy)
        print("f1: ", f1)
        print("precision: ",precision)
        print("auc: ", auc)
        print("recall: ", recall)

        log = {"val_loss": avg_loss,
                "accuracy": val_accuracy,
                "f1": f1,
                "precision":precision,
                "auc":auc,
                "recall":recall
        }

        return {"val_loss": avg_loss,
                "accuracy": val_accuracy,
                "f1": f1,
                "precision":precision,
                "auc":auc,
                "recall":recall,
                "log":log
        }

    def __del__(self):
      # avg_loss = torch.stack([x['val_loss'] for x in outputs_of_validation_steps]).mean()
      # val_accuracy = torch.stack([x['accuracy'] for x in outputs_of_validation_steps]).mean()
      print(len(self.overall_labels_test))
      print(len(self.overall_logits_test))
      # overall_labels_test = self.overall_labels_test
      # overall_logits_test = self.overall_logits_test

      # print(classification_report(list(self.overall_logits_test), list(self.overall_labels_test)))
      # f1 = f1_score(self.overall_logits_test, self.overall_labels_test)
      # print("f1: ", f1)
      # precision = precision_score(self.overall_logits_test, self.overall_labels_test)
      # print("precision: ",precision)
      # recall = recall_score(self.overall_logits_test, self.overall_labels_test)
      # print("recall: ", recall)


      # # if (len(({0}-set(self.overall_logits_test)).union(set(self.overall_logits_test)-{0})))!=0:
      # #   auc = roc_auc_score(self.overall_logits_test, self.overall_labels_test)
      # #   # fpr, tpr, thresholds = metrics.roc_curve(self.overall_logits_val, self.overall_labels_val, pos_label=2)
      # #   # auc = metrics.auc(fpr, tpr)
      # # else:
      # #   auc=0
      # # print(classification_report(self.overall_logits_test, self.overall_labels_test))
      # # print("val accuracy: ", val_accuracy)
      # # print("auc: ", auc)
      


if __name__ == "__main__":
    set_seed(seed=42)
    model = ValidationModel.load_from_checkpoint(parameters["MODEL_PATH"])
    trainer = pl.Trainer(gpus=-1, distributed_backend='dp', max_epochs=parameters["epochs"])
    trainer.test(model)
    
    del trainer
    del model
    print("Main :"+str(len(overall_labels_test)))
    print("Main :"+str(len(overall_logits_test)))
    print(classification_report(overall_logits_test, overall_labels_test))
    f1 = f1_score(overall_logits_test,overall_labels_test)
    print("f1: ", f1)
    precision = precision_score(overall_logits_test, overall_labels_test)
    print("precision: ",precision)
    recall = recall_score(overall_logits_test, overall_labels_test)
    print("recall: ", recall)

    # avg_loss = torch.stack([x['val_loss'] for x in outputs_of_validation_steps]).mean()
    # val_accuracy = torch.stack([x['accuracy'] for x in outputs_of_validation_steps]).mean()
    # f1 = f1_score(trainer.overall_logits_test, trainer.overall_labels_val)
    # precision = precision_score(trainer.overall_logits_test, trainer.overall_labels_val)
    # recall = recall_score(trainer.overall_logits_test, trainer.overall_labels_val)


    if (len(({0}-set(overall_logits_test)).union(set(overall_logits_test)-{0})))!=0:
        #aucRoc = roc_auc_score(overall_logits_test, overall_labels_test)
        aucRoc = roc_auc_score(overall_labels_test, overall_logits_test)
        print("ROC auc: ", aucRoc)
        
        #fpr, tpr, thresholds = roc_curve(overall_labels_test, overall_logits_test, pos_label=1)
        #auc = metrics.auc(fpr, tpr)
        
        # Data to plot precision - recall curve
        precision1, recall1, thresholds = precision_recall_curve(overall_labels_test,  overall_logits_test, pos_label=1)
        # Use AUC function to calculate the area under the curve of precision recall curve
        auc_precision_recall = auc(recall1, precision1)
        print("PR auc: ", auc_precision_recall)
    else:
        auc_precision_recall=0
        aucRoc = 0
        print("ROC auc: ", aucRoc)
        print("PR auc: ", auc_precision_recall)
    # print(classification_report(trainer.overall_logits_test, trainer.overall_labels_test))
    # print("val accuracy: ", val_accuracy)
    # print("f1: ", f1)
    # print("precision: ",precision)
    
    # print("recall: ", recall)
    # model.test()

    #Output the result
    df = pd.DataFrame()
    df["sentence1"] = sent1List
    df["sentence2"] = sent2List
    df["label"] = overall_labels_test
    df["prediction"] = overall_logits_test
    outfileName = sys.argv[2].replace(".csv", "-evalResult.csv")
    df.to_csv(outfileName)