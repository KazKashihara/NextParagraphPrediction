import pandas as pd
import json
import numpy as np


# In[11]:


df = pd.read_json('../reddit/Reddit-train.jsonl',lines=True,orient='records')
df_dev = pd.read_json('../reddit/Reddit-val.jsonl',lines=True,orient='records')
df_test = pd.read_json('../reddit/Reddit-test.jsonl',lines=True,orient='records')


# In[12]:


def getNLIFormat_window(df,window):
  dfsen = pd.DataFrame()
  sentence1 = []
  sentence2 = []
  label = [] 
  for recipe in df.data:
    for step in recipe:
      if len(step['relation_id'])!=0:
        # print(list(set(range(0,len(recipe)))-set(step['relation_id'])))
        for element in step['relation_id']:
          # if np.abs(step['sent_id']-element)<=window:
            sentence1.append(step['sentence'])
            sentence2.append(recipe[element-1]['sentence'])
            label.append(1)
          # else:
          #   sentence1.append(step['sentence'])
          #   sentence2.append(recipe[element]['sentence'])
          #   label.append(0)
        for element in list(set(range(0,len(recipe)))-set(step['relation_id'])):
          if element!=step['sent_id']:
            if np.abs(step['sent_id']-element)<=window:
              sentence1.append(step['sentence'])
              sentence2.append(recipe[element-1]['sentence'])
              label.append(0)
  dfsen['sentence1']=sentence1
  dfsen['sentence2']=sentence2
  dfsen['label']=label
  return dfsen


# In[13]:


def getNLIFormat(df):
  dfsen = pd.DataFrame()
  sentence1 = []
  sentence2 = []
  label = [] 
  for recipe in df.data:
    for step in recipe:
      if len(step['relation_id'])!=0:
        print(list(set(range(0,len(recipe)))-set(step['relation_id'])))
        for element in step['relation_id']:
          sentence1.append(step['sentence'])
          sentence2.append(recipe[element-1]['sentence'])
          label.append(1)
        for element in list(set(range(0,len(recipe)))-set(step['relation_id'])):
          if element!=step['sent_id']:
            sentence1.append(step['sentence'])
            sentence2.append(recipe[element-1]['sentence'])
            label.append(0)
  dfsen['sentence1']=sentence1
  dfsen['sentence2']=sentence2
  dfsen['label']=label
  return dfsen


# In[14]:


# def generate_data_files(df,df_dev,df_test)
df_trainsen = getNLIFormat(df)
df_devsen = getNLIFormat(df_dev)
df_testsen = getNLIFormat(df_test)
df_trainsen_0 = getNLIFormat_window(df,0)
df_devsen_0 = getNLIFormat_window(df_dev,0)
df_testsen_0 = getNLIFormat_window(df_test,0)
df_trainsen_3 = getNLIFormat_window(df,3)
df_devsen_3 = getNLIFormat_window(df_dev,3)
df_testsen_3 = getNLIFormat_window(df_test,3)
df_trainsen_4 = getNLIFormat_window(df,4)
df_devsen_4 = getNLIFormat_window(df_dev,4)
df_testsen_4 = getNLIFormat_window(df_test,4)
df_trainsen_5 = getNLIFormat_window(df,5)
df_devsen_5 = getNLIFormat_window(df_dev,5)
df_testsen_5 = getNLIFormat_window(df_test,5)
df_trainsen.to_csv('../reddit/trainsen_noeq.csv')
df_devsen.to_csv('../reddit/devsen_noeq.csv')
df_testsen.to_csv('../reddit/testsen_noeq.csv')
df_trainsen_0.to_csv('../reddit/trainsen_noeq_0.csv')
df_devsen_0.to_csv('../reddit/devsen_noeq_0.csv')
df_testsen_0.to_csv('../reddit/testsen_noeq_0.csv')
df_trainsen_3.to_csv('../reddit/trainsen_noeq_3.csv')
df_devsen_3.to_csv('../reddit/devsen_noeq_3.csv')
df_testsen_3.to_csv('../reddit/testsen_noeq_3.csv')
df_trainsen_4.to_csv('../reddit/trainsen_noeq_4.csv')
df_devsen_4.to_csv('../reddit/devsen_noeq_4.csv')
df_testsen_4.to_csv('../reddit/testsen_noeq_4.csv')
df_trainsen_5.to_csv('../reddit/trainsen_noeq_5.csv')
df_devsen_5.to_csv('../reddit/devsen_noeq_5.csv')
df_testsen_5.to_csv('../reddit/testsen_noeq_5.csv')
  # return df_trainsen,df_devsen,df_testsen

    
def equal_distribute(df):
  df_2=pd.DataFrame()
  length = []
  for key,data in df.groupby('label'):
    length.append(len(data))
  for key,data in df.groupby('label'):
    # print(key)
    # print(data.sample(n=min(length)))
    df_2 = df_2.append(data.sample(n=min(length)))

  #shuffle the data  
  df_2=df_2.sample(frac=1)
  return df_2



df_trainsen_eq0 = equal_distribute(df_trainsen)
df_trainsen_eq3 = equal_distribute(df_trainsen_3)
df_trainsen_eq4 = equal_distribute(df_trainsen_4)
df_trainsen_eq5 = equal_distribute(df_trainsen_5)



df_trainsen_eq0.to_csv('../reddit/temp/trainsen_eq0.csv')
df_trainsen_eq3.to_csv('../reddit/temp/trainsen_eq3.csv')
df_trainsen_eq4.to_csv('../reddit/temp/trainsen_eq4.csv')
df_trainsen_eq5.to_csv('../reddit/temp/trainsen_eq5.csv')
