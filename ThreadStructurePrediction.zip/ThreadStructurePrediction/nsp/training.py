import torch
from torch import nn
import pytorch_lightning as pl
from torch.nn import functional as F
import pandas as pd
import numpy as np
import random
from transformers import AutoConfig, AutoModel, AutoTokenizer
from torch.utils.data import Dataset, DataLoader
import sys
from pytorch_lightning.callbacks.model_checkpoint import ModelCheckpoint
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score, precision_score
from sklearn.metrics import roc_auc_score, auc, roc_curve
from sklearn.metrics import classification_report
from sklearn import metrics

parameters = {
    "BaseModel": "roberta-large",
    "num_labels": 2,
    "hidden_dropout_prob": 0.15,
    "TRAIN_FILE": sys.argv[1],
    "EVAL_FILE": sys.argv[2],
    "max_length": 250,
    "batch_size": 8,
    "learning_rate": 5e-6,
    "epochs": 8,
}


def set_seed(seed):
    """
    Set the random seed.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class NLIDataset(Dataset):
    def __init__(self, df):
        self.df = df
        self.tokenizer = AutoTokenizer.from_pretrained(parameters["BaseModel"])
        self.label_list = []
        for label in self.df["label"]:
            if label == 0:
                self.label_list.append(0)
            elif label == 1:
                self.label_list.append(1)
            else:
                print("Incorrect Label")

    def __getitem__(self, index):
        sentence1 = self.df.iloc[index]["sentence1"]
        sentence2 = self.df.iloc[index]["sentence2"]
        #label = self.df.iloc[index]["label"]
        label = self.df.iloc[index]["label"]
        encoded_input = self.tokenizer.encode_plus(
            sentence1,
            sentence2,
            add_special_tokens=True,
            truncation=True,
            max_length=parameters["max_length"],
            pad_to_max_length=True,
            return_overflowing_tokens=True,
        )
        if "num_truncated_tokens" in encoded_input and encoded_input["num_truncated_tokens"] > 0:
            # print("Attention! you are cropping tokens")
            pass

        input_ids = encoded_input["input_ids"]
        attention_mask = encoded_input["attention_mask"] if "attention_mask" in encoded_input else None

        token_type_ids = encoded_input["token_type_ids"] if "token_type_ids" in encoded_input else None


        data_input = {
            "input_ids": torch.tensor(input_ids),
            "attention_mask": torch.tensor(attention_mask),
            "labels": torch.tensor(self.label_list[index]),
        }
        if (token_type_ids != None):
            data_input["token_type_ids"] = torch.tensor(token_type_ids)

        return data_input

    def __len__(self):
        return self.df.shape[0]


class ClassificationModel(pl.LightningModule):
    def __init__(self):
        super(ClassificationModel, self).__init__()

        self.config = AutoConfig.from_pretrained(parameters["BaseModel"], num_labels=parameters["num_labels"],
                                                 hidden_dropout_prob=parameters["hidden_dropout_prob"])
        self.base_model = AutoModel.from_pretrained(parameters["BaseModel"], config=self.config)
        self.dropout = nn.Dropout(self.config.hidden_dropout_prob)
        self.classifier = nn.Sequential(
            nn.Linear(self.config.hidden_size, self.config.num_labels),
        )
        self.overall_logits = []
        self.overall_labels=[]
        
        self.overall_logits_val = []
        self.overall_labels_val =[]

    def forward(self,
                input_ids=None,
                attention_mask=None,
                token_type_ids=None,
                labels=None):

        outputs = self.base_model(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        pooled_output = outputs[1]
        dropout_pooled_output = self.dropout(pooled_output)

        logits = self.classifier(dropout_pooled_output)
        softmax_logits = F.softmax(logits, dim=1)
        return pooled_output, logits, softmax_logits

    def prepare_data(self):
        train_df = pd.read_csv(parameters["TRAIN_FILE"])
        train_df = train_df.dropna()
        dev_df = pd.read_csv(parameters["EVAL_FILE"])
        dev_df = dev_df.dropna()

        self.train_dataset = NLIDataset(train_df)
        self.dev_dataset = NLIDataset(dev_df)        

    def train_dataloader(self):
        return DataLoader(dataset=self.train_dataset, batch_size=parameters["batch_size"], shuffle=True, num_workers=8)

    def val_dataloader(self):
        return DataLoader(dataset=self.dev_dataset, batch_size=parameters["batch_size"], num_workers=8)

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=parameters["learning_rate"])

    def loss_function(self, logits, labels):

        loss_fn = torch.nn.CrossEntropyLoss()

        return loss_fn(logits, labels)

    def compute_accuracy(self, logits, labels):
        predicted_label = logits.max(dim=1)[1]
        acc = (predicted_label == labels).float().mean()

        return acc

    def training_step(self, batch, batch_idx):
        bert_output, logits, softmax_logits = self.forward(**batch)
        loss = self.loss_function(logits, batch["labels"])

        # f1 = f1_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # precision = precision_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # recall = recall_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # auc = roc_auc_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        self.overall_logits.extend(logits.cpu().data.numpy().argmax(axis=1))        
        self.overall_labels.extend(batch["labels"].cpu().data.numpy())
        #print(self.overall_logits)
        #print(self.overall_labels)
        
        accuracy = self.compute_accuracy(logits, batch["labels"])

        return {"loss": loss,
                "accuracy": accuracy,
                # "f1": f1,
                # "precision":precision,
                # "recall":recall,
                # "auc":auc,
                "log": {"train_loss": loss, "training_accuracy": accuracy}}


    def validation_step(self, batch, batch_idx):
        bert_output, logits, softmax_logits = self.forward(**batch)
        loss = self.loss_function(logits, batch["labels"])
        m = nn.LogSoftmax(dim=1)

        # print(m(logits))
        # print(logits.max(dim=1)[1].cpu().data.numpy())
        # print(logits.cpu().data.numpy().argmax(axis=1))
        # print(batch["labels"].cpu().data.numpy())
        # f1 = f1_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # precision = precision_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # recall = recall_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        # auc = roc_auc_score(logits.cpu().data.numpy().argmax(axis=1),  batch["labels"].cpu().data.numpy(), average='macro')
        self.overall_logits_val.extend(logits.cpu().data.numpy().argmax(axis=1))        
        self.overall_labels_val.extend(batch["labels"].cpu().data.numpy())

        accuracy = self.compute_accuracy(logits, batch["labels"])

        return {"val_loss": loss,
                "accuracy": accuracy,
                # "f1": f1,
                # "precision":precision,
                # "auc":auc,
                # "recall":recall,
               }

    def validation_epoch_end(self, outputs_of_validation_steps):
        avg_loss = torch.stack([x['val_loss'] for x in outputs_of_validation_steps]).mean()
        val_accuracy = torch.stack([x['accuracy'] for x in outputs_of_validation_steps]).mean()
        # mean_f1 = np.mean([x['f1'] for x in outputs_of_validation_steps])
        # mean_precision = np.mean([x['precision'] for x in outputs_of_validation_steps])
        # mean_recall = np.mean([x['recall'] for x in outputs_of_validation_steps])
        # mean_auc = np.mean([x['auc'] for x in outputs_of_validation_steps])

        print(self.overall_logits_val)
        print(self.overall_labels_val)
        print(set(self.overall_logits_val))
        f1 = f1_score(self.overall_logits_val, self.overall_labels_val)
        precision = precision_score(self.overall_logits_val, self.overall_labels_val)
        recall = recall_score(self.overall_logits_val, self.overall_labels_val)


        if (len(({0}-set(self.overall_logits_val)).union(set(self.overall_logits_val)-{0})))!=0:
          auc = roc_auc_score(self.overall_logits_val, self.overall_labels_val)
          # fpr, tpr, thresholds = metrics.roc_curve(self.overall_logits_val, self.overall_labels_val, pos_label=2)
          # auc = metrics.auc(fpr, tpr)
        else:
          auc=0
        print(classification_report(self.overall_logits_val, self.overall_labels_val))
        print("val accuracy: ", val_accuracy)
        print("f1: ", f1)
        print("precision: ",precision)
        print("auc: ", auc)
        print("recall: ", recall)

        log = {'val_loss': avg_loss, "val_accuracy": val_accuracy}

        return {"val_loss": avg_loss,
                "accuracy": val_accuracy,
                "f1": f1,
                "precision":precision,
                "auc":auc,
                "recall":recall,
                "log":log
        }

        
        # return {'val_loss': avg_loss, "val_accuracy": val_accuracy, 'log': log}


if __name__ == "__main__":
    set_seed(seed=42)
    model = ClassificationModel()

    checkpoint_callback = ModelCheckpoint(monitor="val_accuracy", save_top_k=8, mode='max')
    trainer = pl.Trainer(gpus=-1, distributed_backend='dp', max_epochs=parameters["epochs"],checkpoint_callback=checkpoint_callback)

    # trainer = pl.Trainer(gpus=-1, distributed_backend='dp', max_epochs=parameters["epochs"])
    trainer.fit(model)

