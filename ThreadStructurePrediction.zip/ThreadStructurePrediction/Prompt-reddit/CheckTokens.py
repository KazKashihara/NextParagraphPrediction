import pandas as pd
from transformers import GPT2TokenizerFast
from transformers import AutoConfig, AutoModel, AutoTokenizer

if __name__ == "__main__":
	fileNames = ["RealThreadNewTestSmall2-2.csv", "RedditNewDevSmall2-2.csv", "RedditNewTestSmall2-2.csv", "RedditNewTrainSmall2-2.csv"]
	outputFile = open("PromptDatasetTokenSizeStatistics.txt", "w+")

	tokenizer = AutoTokenizer.from_pretrained("roberta-base")
	tokenizer2 = AutoTokenizer.from_pretrained("bert-base-uncased")
	testSentence = """You are given two posts and you need to generate 1 if they are the direct reply relation, otherwise generate 0.
	input:
	sentence 1:Windows Defender Gets a New Name: Microsoft Defender
	sentence 2:Bring back MSE and its ui even logo looks cool ...bijm
	output:1
	input:
	sentence 1:I was just wondering what the proxy does, does it bypass the new updates only? The spoofer is set to ver 1.0000 I suspect that could have been detected. but you're right any mods are breaking the rules.
	sentence 2:Title says it.
	output:0
	input:
	sentence 1: """
	sampleToken = tokenizer.encode(testSentence)
	sampleToken2 = tokenizer2.encode(testSentence)
	outputFile.write("Format size of Token\n")
	outputFile.write(str(len(sampleToken)) + "\n")
	outputFile.write(str(len(sampleToken2)) + "\n\n")

	for fileName in fileNames:
		df = pd.read_csv(fileName)
		#tokenizer = AutoTokenizer.from_pretrained("roberta-base")
		#tokenizer2 = AutoTokenizer.from_pretrained("bert-base-uncased")

		posts = df["sentence1"].tolist()
		posts2 = df["sentence2"].tolist()
		labels = df["label"].tolist()
		outputFile.write(fileName)
		outputFile.write("\n")

		newDataset1 = []
		newDataset2 = []
		newDSname = fileName.replace(".csv", "-NewRoberta.csv")
		newDSname2 = fileName.replace(".csv", "-NewBERT.csv")
		maxToken1 = 0
		maxToken2 = 0
		avToken1 = 0
		avToken2 = 0
		for i in range(len(posts)):
			post = posts[i]
			post2 = posts2[i]
			label = labels[i]
			tokens1 = tokenizer.encode(post)
			tokens2 = tokenizer.encode(post2)
			if len(tokens1) > maxToken1:
				maxToken1 = len(tokens1)
			avToken1 += len(tokens1)

			if tokens1 < 512 and tokens2 < 512:
				list = []
				list.append(post)
				list.append(post2)
				list.append(labels)
				newDataset1.append(list)

			tokens21 = tokenizer2.encode(post)
			tokens22 = tokenizer2.encode(post2)
			if len(tokens2) > maxToken2:
				maxToken2 = len(tokens2)
			avToken2 += len(tokens2)

			if tokens21 < 512 and tokens22 < 512:
				list = []
				list.append(post)
				list.append(post2)
				list.append(labels)
				newDataset2.append(list)


		outputFile.write("roBERTa Statistic\n")
		outputFile.write("Max Token size is "+ str(maxToken1) + "\n")
		outputFile.write("Average Token size is " + str(avToken1/len(posts)) + "\n")

		outputFile.write("BERT Statistic\n")
		outputFile.write("Max Token size is " + str(maxToken2) + "\n")
		outputFile.write("Average Token size is " + str(avToken2 / len(posts)) + "\n")

		outputFile.write("\n")

		df1 = pd.DataFrame(newDataset1, columns=["sentence1", "sentence2", "label"])
		df1.to_csv(newDSname)

		df2 = pd.DataFrame(newDataset2, columns=["sentence1", "sentence2", "label"])
		df2.to_csv(newDSname2)



	outputFile.close()

